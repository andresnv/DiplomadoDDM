   angular.module('lab1a', [])
        .controller('lab1aController', function($scope){
            $scope.Data = {
				
				"name":"Juan Camil0",
				"id":123456789,
				"profession":"Diseñador",
				"salary":500000,
				"phone":6989898,
				"address":"calle siempre viva"				
            }
        });